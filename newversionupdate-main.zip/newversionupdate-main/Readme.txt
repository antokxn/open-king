1. Unzip archive newverionupdate.zip
2. Unzip archive version_unlimited.rar (Passwor: 1234)
3. Run file setup.exe
